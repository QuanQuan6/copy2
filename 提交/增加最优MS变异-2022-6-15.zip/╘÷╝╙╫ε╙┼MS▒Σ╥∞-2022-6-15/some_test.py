from population import *
from auxiliary import count_time, count_memory



    
